
  # Mobile Audio Player App

  This is a code bundle for Mobile Audio Player App. The original project is available at https://www.figma.com/design/LeK4cz3EXPQIyIDDe9z64z/Mobile-Audio-Player-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  